/**
 * TypeScript mirror of the SCSS tokens in this folder.
 * Values here MUST stay in sync with _colors.scss, _spacing.scss and
 * _typography.scss — this is the pairing Figma tokens sync against,
 * and what any JS-side theming (charts, inline styles) should read from.
 */

export const color = {
  ink: "#14171A",
  inkSecondary: "#5B6470",
  inkTertiary: "#8A929C",
  surface: "#FFFFFF",
  surfaceSubtle: "#F4F5F6",
  surfaceSunken: "#E9EBED",
  border: "#DFE2E6",
  borderStrong: "#C2C7CD",

  accent: "#3457D5",
  accentHover: "#2C49B8",
  accentSubtle: "#EAEFFF",

  success: "#1F9254",
  successSubtle: "#E6F4EC",
  warning: "#B7791F",
  warningSubtle: "#FBF0DE",
  danger: "#C23934",
  dangerSubtle: "#FBEAE9",
  info: "#3457D5",
  infoSubtle: "#EAEFFF",

  focusRing: "rgba(52, 87, 213, 0.35)",
  overlay: "rgba(20, 23, 26, 0.5)",
} as const;

export const space = {
  0: "0",
  1: "4px",
  2: "8px",
  3: "12px",
  4: "16px",
  5: "24px",
  6: "32px",
  7: "48px",
  8: "64px",
} as const;

export const radius = {
  sm: "4px",
  md: "8px",
  lg: "12px",
  full: "999px",
} as const;

export const shadow = {
  sm: "0 1px 2px rgba(20, 23, 26, 0.06)",
  md: "0 4px 12px rgba(20, 23, 26, 0.08)",
} as const;

export const font = {
  heading: '"Sora", "Segoe UI", sans-serif',
  body: '"Inter", "Segoe UI", sans-serif',
  mono: '"JetBrains Mono", "SFMono-Regular", monospace',
} as const;

export const fontSize = {
  xs: "12px",
  sm: "13px",
  md: "14px",
  lg: "16px",
  xl: "18px",
  "2xl": "22px",
  "3xl": "28px",
  "4xl": "36px",
} as const;

export const fontWeight = {
  regular: 400,
  medium: 500,
  semibold: 600,
  bold: 700,
} as const;

export const lineHeight = {
  tight: 1.2,
  normal: 1.5,
  relaxed: 1.7,
} as const;

export const tokens = {
  color,
  space,
  radius,
  shadow,
  font,
  fontSize,
  fontWeight,
  lineHeight,
};

export type Tokens = typeof tokens;
