import type { Meta, StoryObj } from "@storybook/react";
import { color, space, font, fontSize, fontWeight } from "./index";

const meta: Meta = {
  title: "Foundations/Design Tokens",
  tags: ["autodocs"],
};

export default meta;
type Story = StoryObj;

const swatchRow = (name: string, hex: string) => (
  <div key={name} style={{ display: "flex", alignItems: "center", gap: 12 }}>
    <div
      style={{
        width: 32,
        height: 32,
        borderRadius: 6,
        border: "1px solid #DFE2E6",
        background: hex,
      }}
    />
    <span style={{ fontFamily: font.mono, fontSize: 13 }}>{name}</span>
    <span style={{ fontFamily: font.mono, fontSize: 13, color: "#5B6470" }}>
      {hex}
    </span>
  </div>
);

export const Colors: Story = {
  render: () => (
    <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
      {Object.entries(color).map(([name, hex]) => swatchRow(name, hex))}
    </div>
  ),
};

export const Spacing: Story = {
  render: () => (
    <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
      {Object.entries(space).map(([step, value]) => (
        <div key={step} style={{ display: "flex", alignItems: "center", gap: 12 }}>
          <div style={{ width: value, height: 12, background: color.accent }} />
          <span style={{ fontFamily: font.mono, fontSize: 13 }}>
            space[{step}] — {value}
          </span>
        </div>
      ))}
    </div>
  ),
};

export const TypeScale: Story = {
  render: () => (
    <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
      {Object.entries(fontSize).map(([name, size]) => (
        <div
          key={name}
          style={{
            fontFamily: font.heading,
            fontWeight: fontWeight.semibold,
            fontSize: size,
          }}
        >
          {name} — {size} — The quick brown fox
        </div>
      ))}
    </div>
  ),
};
