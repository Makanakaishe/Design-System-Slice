import React, { ButtonHTMLAttributes, forwardRef } from "react";
import styles from "./Button.module.scss";

export type ButtonVariant = "primary" | "secondary" | "ghost" | "danger";
export type ButtonSize = "sm" | "md" | "lg";

export interface ButtonProps
  extends Omit<ButtonHTMLAttributes<HTMLButtonElement>, "size"> {
  /** Visual style. Defaults to "primary". */
  variant?: ButtonVariant;
  /** Controls height, padding, and font size. Defaults to "md". */
  size?: ButtonSize;
  /** Shows a spinner and disables interaction while true. */
  isLoading?: boolean;
  /** Icon rendered before the label. */
  leadingIcon?: React.ReactNode;
}

export const Button = forwardRef<HTMLButtonElement, ButtonProps>(
  (
    {
      variant = "primary",
      size = "md",
      isLoading = false,
      leadingIcon,
      disabled,
      className,
      children,
      ...rest
    },
    ref
  ) => {
    const classes = [
      styles.button,
      styles[variant],
      styles[size],
      isLoading ? styles.loading : "",
      className ?? "",
    ]
      .filter(Boolean)
      .join(" ");

    return (
      <button
        ref={ref}
        className={classes}
        disabled={disabled || isLoading}
        aria-busy={isLoading || undefined}
        {...rest}
      >
        {isLoading && <span className={styles.spinner} aria-hidden="true" />}
        {!isLoading && leadingIcon && (
          <span className={styles.icon}>{leadingIcon}</span>
        )}
        <span className={isLoading ? styles.hiddenLabel : undefined}>
          {children}
        </span>
      </button>
    );
  }
);

Button.displayName = "Button";
