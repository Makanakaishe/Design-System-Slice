import React, { HTMLAttributes } from "react";
import styles from "./Badge.module.scss";

export type BadgeTone = "neutral" | "success" | "warning" | "danger" | "info";

export interface BadgeProps extends HTMLAttributes<HTMLSpanElement> {
  /** Semantic color. Defaults to "neutral". */
  tone?: BadgeTone;
}

export const Badge: React.FC<BadgeProps> = ({
  tone = "neutral",
  className,
  children,
  ...rest
}) => {
  const classes = [styles.badge, styles[tone], className ?? ""]
    .filter(Boolean)
    .join(" ");

  return (
    <span className={classes} {...rest}>
      <span className={styles.dot} aria-hidden="true" />
      {children}
    </span>
  );
};
