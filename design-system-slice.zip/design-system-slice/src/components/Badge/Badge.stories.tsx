import type { Meta, StoryObj } from "@storybook/react";
import { Badge } from "./Badge";

const meta: Meta<typeof Badge> = {
  title: "Components/Badge",
  component: Badge,
  tags: ["autodocs"],
  argTypes: {
    tone: {
      control: "select",
      options: ["neutral", "success", "warning", "danger", "info"],
    },
  },
  args: {
    tone: "neutral",
    children: "Draft",
  },
};

export default meta;
type Story = StoryObj<typeof Badge>;

export const Playground: Story = {};

export const AllTones: Story = {
  render: () => (
    <div style={{ display: "flex", gap: 8 }}>
      <Badge tone="neutral">Draft</Badge>
      <Badge tone="success">Active</Badge>
      <Badge tone="warning">At risk</Badge>
      <Badge tone="danger">Past due</Badge>
      <Badge tone="info">Beta</Badge>
    </div>
  ),
};
