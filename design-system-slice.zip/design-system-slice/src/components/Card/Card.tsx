import React, { HTMLAttributes } from "react";
import styles from "./Card.module.scss";

export type CardPadding = "sm" | "md" | "lg";

export interface CardProps extends HTMLAttributes<HTMLDivElement> {
  /** Inner padding. Defaults to "md". */
  padding?: CardPadding;
  /** Adds a soft elevation shadow instead of a flat border. */
  elevated?: boolean;
}

export const Card: React.FC<CardProps> = ({
  padding = "md",
  elevated = false,
  className,
  children,
  ...rest
}) => {
  const classes = [
    styles.card,
    styles[padding],
    elevated ? styles.elevated : "",
    className ?? "",
  ]
    .filter(Boolean)
    .join(" ");

  return (
    <div className={classes} {...rest}>
      {children}
    </div>
  );
};
