import type { Meta, StoryObj } from "@storybook/react";
import { Card } from "./Card";
import { Badge } from "../Badge";

const meta: Meta<typeof Card> = {
  title: "Components/Card",
  component: Card,
  tags: ["autodocs"],
  argTypes: {
    padding: {
      control: "select",
      options: ["sm", "md", "lg"],
    },
  },
  args: {
    padding: "md",
  },
};

export default meta;
type Story = StoryObj<typeof Card>;

export const Default: Story = {
  render: (args) => (
    <Card {...args} style={{ width: 280 }}>
      <h3 style={{ marginBottom: 8 }}>Northwind Retail</h3>
      <p style={{ margin: 0, color: "#5B6470", fontSize: 13 }}>
        Enterprise plan · 4,821 sessions this month
      </p>
      <div style={{ marginTop: 12 }}>
        <Badge tone="success">Active</Badge>
      </div>
    </Card>
  ),
};

export const Elevated: Story = {
  args: { elevated: true },
  render: Default.render,
};
