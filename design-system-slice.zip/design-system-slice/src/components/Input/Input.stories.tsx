import type { Meta, StoryObj } from "@storybook/react";
import { Input } from "./Input";

const meta: Meta<typeof Input> = {
  title: "Components/Input",
  component: Input,
  tags: ["autodocs"],
  args: {
    label: "Workspace name",
    placeholder: "Acme Inc.",
  },
};

export default meta;
type Story = StoryObj<typeof Input>;

export const Default: Story = {};

export const WithHelperText: Story = {
  args: {
    helperText: "This appears on invoices and shared reports.",
  },
};

export const WithError: Story = {
  args: {
    errorText: "Workspace name can't be empty.",
    defaultValue: "",
  },
};

export const Disabled: Story = {
  args: {
    disabled: true,
    defaultValue: "Acme Inc.",
  },
};
