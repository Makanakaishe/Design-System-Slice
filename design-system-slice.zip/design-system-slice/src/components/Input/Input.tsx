import React, { InputHTMLAttributes, forwardRef, useId } from "react";
import styles from "./Input.module.scss";

export interface InputProps
  extends Omit<InputHTMLAttributes<HTMLInputElement>, "size"> {
  /** Label shown above the field. Always provide one for accessibility. */
  label: string;
  /** Helper copy shown below the field when there is no error. */
  helperText?: string;
  /** Error message. When set, the field switches to its error styling. */
  errorText?: string;
}

export const Input = forwardRef<HTMLInputElement, InputProps>(
  ({ label, helperText, errorText, disabled, id, className, ...rest }, ref) => {
    const generatedId = useId();
    const inputId = id ?? generatedId;
    const helperId = `${inputId}-helper`;
    const hasError = Boolean(errorText);

    return (
      <div className={[styles.field, className ?? ""].join(" ")}>
        <label className={styles.label} htmlFor={inputId}>
          {label}
        </label>
        <input
          ref={ref}
          id={inputId}
          disabled={disabled}
          aria-invalid={hasError || undefined}
          aria-describedby={helperText || errorText ? helperId : undefined}
          className={[styles.input, hasError ? styles.inputError : ""].join(
            " "
          )}
          {...rest}
        />
        {(helperText || errorText) && (
          <span
            id={helperId}
            className={hasError ? styles.errorText : styles.helperText}
          >
            {errorText || helperText}
          </span>
        )}
      </div>
    );
  }
);

Input.displayName = "Input";
