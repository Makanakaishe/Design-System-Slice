import type { Preview } from "@storybook/react";
import "../src/styles/global.scss";

const preview: Preview = {
  parameters: {
    layout: "centered",
    controls: {
      matchers: {
        color: /(background|color)$/i,
      },
    },
    backgrounds: {
      default: "subtle",
      values: [
        { name: "subtle", value: "#F4F5F6" },
        { name: "white", value: "#FFFFFF" },
        { name: "ink", value: "#14171A" },
      ],
    },
  },
};

export default preview;
