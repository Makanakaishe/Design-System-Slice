# 🎨 Design System Slice

A foundational slice of a design system: design tokens, a small set of
core components, and Storybook documentation for each — built to grow
into a full library without changing its structure.

## 🛠️ Stack

| Layer    | Tools                                      |
|----------|---------------------------------------------|
| Frontend | React + TypeScript, Storybook               |
| Styling  | SCSS Modules, Stylelint                     |
| UI/UX    | Design tokens (colors, spacing, typography) sourced from Figma |

## 📁 Structure

```
src/
  tokens/
    _colors.scss          # color tokens (SCSS)
    _spacing.scss         # spacing + radius + shadow tokens (SCSS)
    _typography.scss      # font, size, weight tokens (SCSS)
    _index.scss           # forwards all token partials
    index.ts              # TS mirror of the same tokens, for JS consumers
    Tokens.stories.tsx    # visual doc: color swatches, spacing scale, type scale
  styles/
    _mixins.scss          # focus ring, truncate, font helpers
    global.scss           # resets + base type, loaded once in Storybook
  components/
    Button/
    Input/
    Badge/
    Card/
      *.tsx               # component
      *.module.scss       # scoped styles, built on tokens
      *.stories.tsx       # Storybook stories per state/variant
      index.ts            # public export
  index.ts                # package-level barrel export
```

## 🧩 Components in this slice

- **Button** — `primary` / `secondary` / `ghost` / `danger`, three sizes,
  loading and disabled states
- **Input** — labeled field with helper text and error state
- **Badge** — status pill in five semantic tones
- **Card** — content container with padding and elevation options

Each component's `.stories.tsx` file documents every state it supports —
this is the project's substitute for a Figma states-checklist: loading,
error, empty/disabled, and all variants are one click away in Storybook.

## 🎯 Design tokens

Tokens are the single source of truth for color, spacing, and type, and
are meant to be generated from Figma variables (colors, spacing, and
typography styles) and kept in sync here by hand or via a token-sync
script. They exist in two parallel forms:

- **SCSS** (`_colors.scss`, `_spacing.scss`, `_typography.scss`) — used
  directly by component styles via `@use "../../tokens" as t;`
- **TypeScript** (`index.ts`) — used anywhere a JS value is needed
  instead of a class name (inline styles, chart theming, the token
  documentation page itself)

Because these are two files instead of one generated artifact, **any
token change must be made in both places** — see the comment at the top
of each file as a reminder.

## 🚀 Getting started

```bash
npm install
npm run storybook
```

Storybook opens at `http://localhost:6006` with every component and the
token documentation page (**Foundations → Design Tokens**).

```bash
npm run build-storybook   # static build for hosting/sharing
npm run lint:css          # Stylelint across all component styles
npm run typecheck         # TypeScript, no emit
```

## ✅ Stylelint

`.stylelintrc.json` extends `stylelint-config-standard-scss` and adds:
- a fixed property ordering (position → box model → typography) so
  diffs stay small and predictable
- `camelCase` enforcement for class names and SCSS variables, matching
  the CSS Modules import style used in every component (`styles.button`,
  not `styles["button-primary"]`)

## 🗺️ Roadmap

- [ ] Figma token sync script (Figma Variables API → `tokens/*.scss` + `index.ts`)
- [ ] Additional components: Select, Checkbox, Tooltip, Modal
- [ ] Dark theme token set
- [ ] Visual regression testing via Chromatic

## 📄 License

MIT — see `LICENSE` for details.
